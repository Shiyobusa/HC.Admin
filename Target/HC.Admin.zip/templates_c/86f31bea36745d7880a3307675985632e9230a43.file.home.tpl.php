<?php /* Smarty version Smarty-3.1.13, created on 2013-05-11 18:54:50
         compiled from "templates\home.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5127518e77da45c818-19827992%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '86f31bea36745d7880a3307675985632e9230a43' => 
    array (
      0 => 'templates\\home.tpl',
      1 => 1368290349,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5127518e77da45c818-19827992',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'username' => 0,
    'server_status' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_518e77da4a0490_29310822',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_518e77da4a0490_29310822')) {function content_518e77da4a0490_29310822($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ('templates/header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>


<table class="header">
<tr>
<td>Welcome <?php echo $_smarty_tpl->tpl_vars['username']->value;?>
<a style="color:grey;" href="?action=logout"> (Logout)</a></td>
<?php if ($_smarty_tpl->tpl_vars['server_status']->value==="online"){?>
<td>Servidor <a style="color:green;">ONLINE</a></td>
<?php }elseif($_smarty_tpl->tpl_vars['server_status']->value==="offline"){?>
<td>Servidor <a style="color:red;">OFFLINE</a></td>
<?php }?>
</tr>
</table> 

<div class="form">
<form action="index.php" method="get">
<input type="hidden" name="action" value="start"><br>
<div class="buttom_submit"><input class="inp_submit"type="submit" value="Start server"></div>
</form>
</div>

<div class="form" style="margin-top:-30px;">
<form action="index.php" method="get">
<input type="hidden" name="action" value="stop"><br>
<div class="buttom_submit"><input class="inp_submit"type="submit" value="Turn off server"></div>
</form>
</div>

<div class="form" style="margin-top:-30px;">
<form action="index.php" method="get">
<input type="hidden" name="action" value="restart"><br>
<div class="buttom_submit"><input class="inp_submit"type="submit" value="Restart server"></div>
</form>
</div>


<?php echo $_smarty_tpl->getSubTemplate ('templates/footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null, array(), 0);?>
<?php }} ?>