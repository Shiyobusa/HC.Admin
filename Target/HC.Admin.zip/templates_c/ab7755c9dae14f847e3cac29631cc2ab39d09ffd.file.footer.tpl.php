<?php /* Smarty version Smarty-3.1.13, created on 2013-05-11 18:54:50
         compiled from "templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:861518e77da4b8722-67425227%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'ab7755c9dae14f847e3cac29631cc2ab39d09ffd' => 
    array (
      0 => 'templates\\footer.tpl',
      1 => 1368201329,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '861518e77da4b8722-67425227',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_518e77da4b9aa6_77380172',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_518e77da4b9aa6_77380172')) {function content_518e77da4b9aa6_77380172($_smarty_tpl) {?></body>
</html><?php }} ?>