<?php /* Smarty version Smarty-3.1.13, created on 2013-05-11 18:54:50
         compiled from "templates\header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:22836518e77da4ab338-57643981%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '20a5b87bf1d249a8e4b5bdf6dc560aa9c65c681a' => 
    array (
      0 => 'templates\\header.tpl',
      1 => 1368204934,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '22836518e77da4ab338-57643981',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'zone' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_518e77da4afe79_62044693',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_518e77da4afe79_62044693')) {function content_518e77da4afe79_62044693($_smarty_tpl) {?><!DOCTYPE html>
<html lang="es-ES">
	<head>
	<title>HCAdmin. <?php echo $_smarty_tpl->tpl_vars['zone']->value;?>
</title>
	<meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="templates/css/style.css" />
	</head>
<body>
<?php }} ?>